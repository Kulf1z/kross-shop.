const products = [
  {id:1,name:"Air Force 1 '07",category:"low",price:8990,tag:"BESTSELLER",desc:"Классика на каждый день",img:"https://images.unsplash.com/photo-1603278806177-6e9a6f7f0d6b?auto=format&fit=crop&w=900&q=85"},
  {id:2,name:"Dunk Low Retro",category:"low",price:10990,tag:"POPULAR",desc:"Чистый силуэт и комфорт",img:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=85"},
  {id:3,name:"Jordan 1 Mid",category:"mid",price:13990,tag:"NEW DROP",desc:"Легендарный баскетбольный стиль",img:"https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&w=900&q=85"},
  {id:4,name:"Jordan 1 High",category:"high",price:16990,tag:"ICONIC",desc:"Высокий профиль, сильный характер",img:"https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?auto=format&fit=crop&w=900&q=85"},
  {id:5,name:"New Balance 550",category:"low",price:12490,tag:"TRENDING",desc:"Ретро-баскетбольная эстетика",img:"https://images.unsplash.com/photo-1539185441755-769473a23570?auto=format&fit=crop&w=900&q=85"},
  {id:6,name:"Classic High",category:"high",price:9990,tag:"ESSENTIAL",desc:"Универсальная пара для города",img:"https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&w=900&q=85"}
];
const money = n => new Intl.NumberFormat("ru-RU").format(n) + " ₽";
let cart = JSON.parse(localStorage.getItem("krossCart") || "[]");
let filter = "all";
const productsEl = document.getElementById("products");

function renderProducts(){
  const q = document.getElementById("search").value.toLowerCase().trim();
  let list = products.filter(p => (filter === "all" || p.category === filter) && (p.name.toLowerCase().includes(q) || p.desc.toLowerCase().includes(q)));
  const sort = document.getElementById("sort").value;
  if(sort === "asc") list.sort((a,b)=>a.price-b.price);
  if(sort === "desc") list.sort((a,b)=>b.price-a.price);
  productsEl.innerHTML = list.length ? list.map(p=>`<article class="product">
    <div class="product-image"><span class="badge">${p.tag}</span><img src="${p.img}" alt="${p.name}" loading="lazy" onerror="this.style.display='none';this.parentElement.insertAdjacentHTML('beforeend','<b style=&quot;font-size:64px;color:#444;font-style:italic&quot;>K</b>')"></div>
    <div class="product-info"><h3>${p.name}</h3><p>${p.desc}</p><div class="product-bottom"><span class="price">${money(p.price)}</span><button class="add" data-add="${p.id}">В корзину +</button></div></div>
  </article>`).join("") : '<p class="no-results">Ничего не найдено. Попробуй другой запрос.</p>';
}
function save(){localStorage.setItem("krossCart",JSON.stringify(cart));renderCart();}
function renderCart(){
  const count=cart.reduce((s,i)=>s+i.qty,0), total=cart.reduce((s,i)=>s+i.price*i.qty,0);
  document.getElementById("cartCount").textContent=count;
  document.getElementById("cartTotal").textContent=money(total);
  document.getElementById("cartItems").innerHTML=cart.length?cart.map(i=>`<div class="cart-row"><div>${i.name}<small>${money(i.price)} × ${i.qty}</small></div><div><b>${money(i.price*i.qty)}</b><button class="remove" data-remove="${i.id}"> Удалить</button></div></div>`).join(""):'<p class="empty">Пока здесь пусто.</p>';
}
productsEl.addEventListener("click",e=>{const b=e.target.closest("[data-add]");if(!b)return;const p=products.find(x=>x.id===Number(b.dataset.add));const old=cart.find(x=>x.id===p.id);old?old.qty++:cart.push({...p,qty:1});save();b.textContent="Добавлено ✓";setTimeout(()=>b.textContent="В корзину +",900);});
document.getElementById("cartItems").addEventListener("click",e=>{const b=e.target.closest("[data-remove]");if(!b)return;cart=cart.filter(i=>i.id!==Number(b.dataset.remove));save();});
document.getElementById("filters").addEventListener("click",e=>{const b=e.target.closest("[data-filter]");if(!b)return;filter=b.dataset.filter;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));renderProducts();});
document.getElementById("search").addEventListener("input",renderProducts);
document.getElementById("sort").addEventListener("change",renderProducts);
const drawer=document.getElementById("cartDrawer"),overlay=document.getElementById("overlay");
function openCart(){drawer.classList.add("open");overlay.classList.add("show");}
function closeCart(){drawer.classList.remove("open");overlay.classList.remove("show");}
document.getElementById("openCart").addEventListener("click",openCart);
document.getElementById("closeCart").addEventListener("click",closeCart);
overlay.addEventListener("click",closeCart);
document.getElementById("orderForm").addEventListener("submit",async e=>{
  e.preventDefault();const msg=document.getElementById("formMessage");
  if(!cart.length){msg.textContent="Сначала добавь товары в корзину.";return;}
  const form=new FormData(e.target), total=cart.reduce((s,i)=>s+i.price*i.qty,0);
  const payload={name:form.get("name"),phone:form.get("phone"),items:cart.map(({id,name,price,qty})=>({id,name,price,qty})),total};
  const btn=e.target.querySelector("button");btn.disabled=true;btn.textContent="Отправляем…";
  try{const r=await fetch("/api/order",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});const data=await r.json();if(!r.ok)throw new Error(data.error||"Ошибка");msg.textContent=data.message;cart=[];save();e.target.reset();}
  catch(err){msg.textContent=err.message||"Не удалось отправить заказ. Попробуй позже.";}
  finally{btn.disabled=false;btn.textContent="Оформить заказ ↗";}
});
renderProducts();renderCart();