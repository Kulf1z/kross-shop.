const http = require("http");
const fs = require("fs");
const path = require("path");

const ROOT = __dirname;
const PORT = process.env.PORT || 3000;
const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml"
};

function send(res, status, body, type = "application/json; charset=utf-8") {
  res.writeHead(status, { "Content-Type": type, "X-Content-Type-Options": "nosniff" });
  res.end(body);
}

const server = http.createServer((req, res) => {
  if (req.method === "POST" && req.url === "/api/order") {
    let raw = "";
    req.on("data", chunk => {
      raw += chunk;
      if (raw.length > 100_000) req.destroy();
    });
    req.on("end", async () => {
      try {
        const order = JSON.parse(raw || "{}");
        if (!order.name || !order.phone || !Array.isArray(order.items) || !order.items.length) {
          return send(res, 400, JSON.stringify({ error: "Заполните имя, телефон и добавьте товары." }));
        }
        const lines = order.items.map(i => `${i.name} × ${i.qty} — ${i.price * i.qty} ₽`).join("\n");
        const message = `🛍 Новый заказ KROSS SHOP\nИмя: ${order.name}\nТелефон: ${order.phone}\n\n${lines}\n\nИтого: ${order.total} ₽`;
        if (process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_CHAT_ID) {
          const tg = await fetch(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ chat_id: process.env.TELEGRAM_CHAT_ID, text: message })
          });
          if (!tg.ok) console.error("Telegram notification failed:", await tg.text());
        } else {
          console.log(message);
        }
        return send(res, 200, JSON.stringify({ ok: true, message: "Заказ принят! Мы свяжемся с вами." }));
      } catch (e) {
        console.error(e);
        return send(res, 400, JSON.stringify({ error: "Не удалось обработать заказ." }));
      }
    });
    return;
  }

  const pathname = decodeURIComponent((req.url || "/").split("?")[0]);
  const safePath = pathname === "/" ? "/index.html" : pathname;
  const fullPath = path.join(ROOT, safePath);
  if (!fullPath.startsWith(ROOT)) return send(res, 403, "Forbidden", "text/plain");
  fs.readFile(fullPath, (err, data) => {
    if (err) return send(res, 404, "Not found", "text/plain; charset=utf-8");
    send(res, 200, data, MIME[path.extname(fullPath)] || "application/octet-stream");
  });
});

server.listen(PORT, "0.0.0.0", () => console.log(`KROSS SHOP running on ${PORT}`));